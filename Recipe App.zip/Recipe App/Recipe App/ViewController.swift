//
//  ViewController.swift
//  Recipe App
//
//  Created by Aditya kumar on 22/10/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btnstart(_ sender: Any) {
        self.performSegue(withIdentifier: "s1", sender: nil)
    }
    
}

