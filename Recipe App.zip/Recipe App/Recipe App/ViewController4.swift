//
//  ViewController4.swift
//  Recipe App
//
//  Created by Aditya kumar on 22/10/23.
//

import UIKit
var name = String()
var ingredients1 = ["Tomato", "Chicken", "Breads", "Eggs", "Carrot"]
class ViewController4: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lbName.text="\(name)"
        
//        self.performSegue(withIdentifier: "s5", sender: nil)
        
    }
    
    @IBOutlet weak var lbName: UILabel!
    
    @IBOutlet weak var mysegment: UISegmentedControl!
    
    @IBOutlet weak var sgImg1: UIImageView!
    @IBOutlet weak var sgImg2: UIImageView!
    @IBOutlet weak var sgImg3: UIImageView!
    @IBOutlet weak var sgimg4: UIImageView!
    
    @IBOutlet weak var sgLb1: UILabel!
    @IBOutlet weak var sgLb2: UILabel!
    @IBOutlet weak var sgLb3: UILabel!
    @IBOutlet weak var sgLb4: UILabel!
    
    @IBOutlet weak var card3: CardView!
    @IBOutlet weak var card4: CardView!
    
    
    @IBAction func btn1(_ sender: UIButton) {
        var value = mysegment.selectedSegmentIndex
        switch value {
        case 0:
            pdata = "Aloo Puri"
            cat = "Breakfast"
            time = "20 Minutes"
            steps = ["1. Heat oil in a 20 litre stovetop pressure cooker. Add 1 teaspoon ajwain (carom seeds) and fry them till they splutter.", "2. Now add ⅓ cup chopped onions (about 1 medium-sized onion, or 50 grams).", "3. Then add 2 teaspoons finely chopped ginger (1-inch ginger), 1 teaspoon finely chopped garlic (2 to 3 small to medium garlic cloves) and 1 to 2 chopped green chillies.", "4. Add 1 heaped cup chopped tomatoes (about 2 medium to large tomatoes or 200 grams).", "5. Now add 2 heaped cups peeled, diced potatoes (about 5 medium-sized potatoes or 350 grams)."]
            imgName = "img8"
            print("Aloo Puri")
        case 1:
            pdata = "Paneer Butter Masala"
            cat = "Lunch"
            time = "10 Minutes"
            steps = ["1. Soak 18 to 20 cashews in ⅓ cup hot water for 20 to 30 minutes.", "2. While the cashews are soaking, you can prep the other ingredients. It’s time for chopping tomatoes, chopping and preparing the ginger-garlic paste.", "3. To make the ginger garlic paste, crush a 1 inch piece of peeled ginger with 3 to 4 small to medium-sized garlic cloves in a mortar & pestle.", "4. After 20 to 30 minutes, drain the water and add the soaked cashews to a blender or mixer-grinder.", "5. Blend to a smooth paste without any tiny bits or chunks of cashews. Remove the cashew paste from the blender and set it aside."]
            imgName = "img5"
            print("Paneer Butter Masala")
            
        case 2:
            pdata = "Bhindi Masala"
            cat = "Dinner"
            time = "30 Minutes"
            steps = ["1. Blend to a smooth paste without any tiny bits or chunks of cashews. Remove the cashew paste from the blender and set it aside.", "2. When they are completely dry, chop each bhindi in 1 or 2 inch pieces.Before chopping, make sure there is not even a single drop of water or any moisture.", "3. In a heavy kadai, pan or skillet, heat 2 tablespoons oil and add the chopped okra. You can use any neutral-tasting oil.", "4. Remove the cooked bhindi in a plate and keep aside. Also chop onions, tomatoes, green chilies and keep aside. Crush ginger and ginger-garlic paste.", "5. In the same kadai or pan, heat 1 tablespoon oil. Add 1 medium-sized chopped onion (⅓ cup chopped onions)."]
            imgName = "img12"
            print("Bhindi Masla")
        default: break
        }
        self.performSegue(withIdentifier: "s5", sender: self)
    }
    
    @IBAction func btn2(_ sender: UIButton) {
        var value = mysegment.selectedSegmentIndex
        switch value {
        case 0:
            pdata = "Punjabi Chole Masala"
            cat = "Breakfast"
            time = "30 Minutes"
            steps = ["1. Rinse 1 cup dried white chickpeas (a.k.a. chana or chole) in fresh water a couple of times. Then soak them overnight or for 8 to 9 hours in 3 cups of water.", "2. Traditionally dried amla (Indian gooseberries) are added to impart a dark color to the chickpeas. Amla also gives a faint sourness to the stock.", "3. In a 3 litre stovetop pressure cooker, add the chickpeas along with 2 to 3 dried amla pieces or 1 black tea bag. Add 2.5 to 3 cups of water.", "4. Pressure cook the chickpeas for 12 to 15 whistles on medium heat. The chickpeas should be cooked well and softened enough that you can mash them with a spoon.", "5. Meanwhile, add all the whole spices for the chole masala to a pan or skillet. Begin to roast them on a low heat."]
            imgName = "img9"
            print("Punjabi Chole Masala")
        case 1:
            pdata = "Masala Dosa"
            cat = "Lunch"
            time = "50 Minutes"
            steps = ["1. Heat a well seasoned frying pan or the tawa or a flat cast iron skillet. Spread the dosa batter. If using non-stick pan, then don’t spread oil.", "2. Sprinkle some oil on the sides of the dosa. Cover the dosa with a lid and let it cook.", "3. When the top side is cooked, spread some more oil if you prefer on the dosa. Spread the Red Chutney on the dosa all around.", "4. Top the dosa with the potato filling and spread it lightly.", "5. Serve Mysore Masala Dosa hot with coconut chutney and veg sambar. Prepare the remaining dosa this way one by one."]
            imgName = "img4"
            print("Masala Dosa")
            
        case 2:
            pdata = "Matar Paneer"
            cat = "Dinner"
            time = "35 Minutes"
            steps = ["1. First, you will take all of the masala paste ingredients and add them to a grinder or a blender.", "2. After that, you will grind the ingredients into a smooth paste. If needed add 2 to 3 tablespoons of water while grinding the masala paste.", "3. Next add 3 tablespoons oil in a 2-litre pressure cooker or a pot. Let the oil become hot. Reduce heat to a medium-low heat.", "4. Next, add in your ground masala paste, and mix well.", "5. Now you will sauté the paste mixture for about 10 to 12 minutes on a medium-low heat."]
            imgName = "img14"
            print("Matar Paneer")
        default: break
        }
        self.performSegue(withIdentifier: "s5", sender: self)
    }
    
    @IBAction func btn3(_ sender: UIButton) {
        var value = mysegment.selectedSegmentIndex
        switch value {
        case 0:
            pdata = "Bread Pakora"
            cat = "Breakfast"
            time = "15 Minutes"
            steps = ["1. Boil or steam 2 medium-sized or 1 large potato in a pressure cooker or steamer or in the IP until they are fork tender.", "2. First add ½ cup water and mix very well. Batter consistency should not be very thick nor too thin. If it is too thick, then add more water.", "3. To the batter, add 1 to 2 teaspoons of hot oil when you keep the oil for deep frying on the stove-top. Stir and mix well.", "4. On the chopping board, slice the bread into triangle or rectangle slices.", "5. Take around 2 to 3 tablespoons of the mashed potato mixture and spread it on the bread evenly."]
            imgName = "img10"
            print("Bread Pakora")
        case 1:
            pdata = "Dal Makhni"
            cat = "Lunch"
            time = "35 Minutes"
            steps = ["1. Soak both ¾ cup whole urad dal (whole black gram) and ¼ cup rajma (kidney beans) overnight in enough water for 8 to 9 hours. Drain them well.", "2. Rinse the urad lentils and rajma legumes a couple of times in water.", "3. Drain well and then add them in a 3 litre pressure cooker.", "4. Pressure cook for 18 to 20 whistles on a high flame, till both the whole urad dal and rajma have cooked thoroughly and softened.", "5. both the rajma and urad dal are cooked and softened well."]
            imgName = "img7"
            print("Dal Makhni")
            
        default: break
        }
        self.performSegue(withIdentifier: "s5", sender: self)
    }
    
    
    @IBAction func btn4(_ sender: UIButton) {
        var value = mysegment.selectedSegmentIndex
        switch value {
        case 0:
            pdata = "Pudina Prantha"
            cat = "Breakfast"
            time = "20 Minutes"
            steps = ["1. Begin with rinsing the mint leaves and keeping them aside. We will use 1 cup of tightly packed fresh mint leaves, of which half is added to the dough.", "2. Then start with the dough preparation – in a mixing bowl or pan, take 2 cups whole wheat flour (240 grams), 2 teaspoon oil or ghee or butter.", "3. Then add ½ cup tightly packed fresh mint leaves, which have been chopped finely.", "4. Add more water as required and knead to a smooth dough. Overall I used ⅔ cup of water to knead the dough. ", "5. When the dough is resting, you can prepare the spice mix. In a pan, add ½ cup tightly packed fresh mint leaves."]
            imgName = "img11"
            print("Pudina Prantha")
        case 1:
            pdata = "Rajma Chawal"
            cat = "Lunch"
            time = "30 Minutes"
            steps = ["1. Sort dried beans and discard any misshapen or discolored beans. Rinse a couple of times, and then soak 1 cup rajma (kidney beans) in enough water to cover them.", "2. Soaking should ideally last for 8 to 9 hours, so I usually soak them the night before I cook. Once the beans are well soaked, discard the soaking water. Drain and rinse the soaked beans a few times to remove any leftover grit, if any.", "3. Add 3.5 to 4 cups of water and stir. Pressure cook the rajma for 18 to 20 whistles (or for about 15 to 20 minutes).", "4. When the pressure settles down on its own in the cooker, open the lid. Check if the rajma is cooked or not by eating or pressing a bean with your fingers.", "5. Heat either 3 tablespoons of butter (or 2 tablespoons butter + 1 tablespoon oil), in another pot or pan or kadai. Keep the heat to low or medium-low."]
            imgName = "img13"
            print("Rajma Chawal")
            
        default: break
        }
        self.performSegue(withIdentifier: "s5", sender: self)
    }
    
    
    @IBAction func mySegmentCall(_ sender: Any) {
        var value = mysegment.selectedSegmentIndex
        switch value {
        case 0:
            sgImg1.image = UIImage(named: "img8")
            sgLb1.text = "Aloo Puri"
            
            sgImg2.image = UIImage(named: "img9")
            sgLb2.text = "Punjabi Chole Masala"
            
            card3.isHidden = false
            card4.isHidden = false
            
            sgImg3.image = UIImage(named: "img10")
            sgLb3.text = "Bread Pakora"
            
            sgimg4.image = UIImage(named: "img11")
            sgLb4.text = "Punjabi Prantha"
            
            
        case 1:
            sgImg1.image = UIImage(named: "img5")
            sgLb1.text = "Panner Butter Masala"
            
            sgImg2.image = UIImage(named: "img4")
            sgLb2.text = "Masala Dosa"
            
            card3.isHidden = false
            card4.isHidden = false
            
            sgImg3.image = UIImage(named: "img7")
            sgLb3.text = "Dal Makhni"
            
            sgimg4.image = UIImage(named: "img13")
            sgLb4.text = "Rajma Chawal"
            
            
        case 2:
            sgImg1.image = UIImage(named: "img12")
            sgLb1.text = "Bhindi Masala"
            
            sgImg2.image = UIImage(named: "img14")
            sgLb2.text = "Matar Paneer"
            
            card3.isHidden = true
            card4.isHidden = true
            
            
        default: break
        }
        
    }
    
}
