//
//  ViewController3.swift
//  Recipe App
//
//  Created by Aditya kumar on 22/10/23.
//

import UIKit
struct User {
    var username: String
    var password: String
    // Add other user information fields as needed
}
var registeredUsers = [User]()
class ViewController3: UIViewController {
    
    
    // Array to store registered users
    
    
    // Function to handle user registration
    func registerUser(username: String, password: String) {
        let newUser = User(username: username, password: password)
        registeredUsers.append(newUser)
        for user in registeredUsers {
            print("User registered: \(user.username), Password: \(user.password)")
        }
        
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBOutlet weak var lb: UILabel!
    
    @IBOutlet weak var username: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    @IBOutlet weak var cpassword: UITextField!
    
    @IBAction func registerbtn(_ sender: Any) {
        let n = username.text!
        let pass = password.text!
        let cpass = cpassword.text!
        
        if(n.isEmpty || pass.isEmpty || cpass.isEmpty) {
            let alert = UIAlertController(title: "Warning", message: "All fields are mandatory", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }

        if(pass != cpass) {
            let alert = UIAlertController(title: "Error", message: "Password & Confirm Password doesn't match", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else {
            let actionPerformed = {
                (action: UIAlertAction) -> Void in
                users = registeredUsers
                self.performSegue(withIdentifier: "s4", sender: nil)
            }
            let alert = UIAlertController(title: "Message", message: "Account Created Successfully!", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: actionPerformed))
            self.present(alert, animated: true, completion: nil)
            self.registerUser(username: n, password: pass)
        }
        
    }
    
    @IBAction func loginBtn(_ sender: Any) {
        self.performSegue(withIdentifier: "s4", sender: nil)
    }
}
