//
//  ViewController5.swift
//  Recipe App
//
//  Created by Aditya kumar on 28/10/23.
//

import UIKit
import AVKit
import AVFoundation

var pdata = String()
var cat = String()
var time = String()
var steps = Array<String>()
var imgName = String()
class ViewController5: ViewController {

    
    @IBOutlet weak var lbCategory: UILabel!
    
    @IBOutlet weak var lb: UILabel!
    @IBOutlet weak var lbTime: UILabel!
    
    @IBOutlet weak var txt1: UITextView!
    
    @IBOutlet weak var txt2: UITextView!
    
    @IBOutlet weak var txt3: UITextView!
    
    @IBOutlet weak var txt4: UITextView!
    
    @IBOutlet weak var img: UIImageView!
    
    @IBOutlet weak var txt5: UITextView!
    
    @IBOutlet weak var lb2: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        lb.text = "\(pdata)"
        
        lbCategory.text = "\(cat)"
        lbTime.text = "\(time)"
        lb2.text = "How to Make \(pdata) Recipe"
        txt1.text = steps[0]
        txt2.text = steps[1]
        txt3.text = steps[2]
        txt4.text = steps[3]
        txt5.text = steps[4]
        img.image = UIImage(named: "\(imgName)")
    }
    


}
