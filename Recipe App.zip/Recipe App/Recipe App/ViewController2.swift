//
//  ViewController2.swift
//  Recipe App
//
//  Created by Aditya kumar on 22/10/23.
//

import UIKit
var users = [User]()
var showAlert = true;
class ViewController2: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var username: UITextField!
    
    
    @IBOutlet weak var password: UITextField!
    
    @IBAction func loginBtn(_ sender: Any) {
        let username = username.text!
        let password = password.text!
        
        if(username.isEmpty || password.isEmpty) {
            let alert = UIAlertController(title: "Warning", message: "All fields are mandatory!", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
        name = username
        for user in users {
            if(user.username == username && user.password == password) {
                showAlert = false
                let actionPerformed = {
                    (action: UIAlertAction) -> Void in
                    self.performSegue(withIdentifier: "s3", sender: nil)
                }
                let alert = UIAlertController(title: "Message", message: "Login Successfull!", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: actionPerformed))
                self.present(alert, animated: true, completion: nil)
                
            }
        }
        if(showAlert) {
            let alert = UIAlertController(title: "Message", message: "Invalid User Credentials!", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    @IBAction func registerBtn(_ sender: Any) {
        self.performSegue(withIdentifier: "s2", sender: nil)
    }
}
